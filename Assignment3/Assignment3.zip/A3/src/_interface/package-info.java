@javax.xml.bind.annotation.XmlSchema(namespace = "http://Interface/")
package _interface;
